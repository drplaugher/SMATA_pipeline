function FF = TruthTable_del_a_temp(F,nv,varF,p,tail,head,v)
% arrow to delete (tail,head)
 
% David Murrugarra; Jul 23, 2018

%  n = length(nv);

if ismember(tail, varF(:,head))
   [~,loc] = ismember(tail, varF(:,head));
%     disp(loc);
%     disp([tail head]);
end
FF = F;
% FF(1:p^(nv(head)),head) = -1*ones(p^(nv(head)),1);
% disp(FF(:,head));
% nv1 = nv;
% nv1(head) = nv(head)-1;
% varF1 = varF;
% varF1(loc,head) = -1;
% I = find(varF1(:,head)==-1);
% varF1(I,head) = 100;
% 
% [Y,I] = sort(varF1(:,head));
% varF1(:,head) = Y;
% I = find(varF1(:,head)==100);
% varF1(I,head) = -1;

% b = p.^(size(varF,1)-1:-1:0)';
% disp(b)
% x = ff2n(nv(head));
for i = 1 : p^(nv(head))
    x = dec2multistate(i-1,p,nv(head));
%     disp(x)
    if x(loc) ~= v
%        y = x;
%        y(loc) = [];
%        disp(y);
%        decy = multistate2dec(y,p,nv1(head));
%        FF(decy,head) = F(x*b(end-nv(head)+1:end)+1,head);
        % use only rows with v value in the loc column
       x(loc) = v;
%        disp(x);
        decx = multistate2dec(x,p,nv(head));
%         disp(decx)
        FF(i,head) = F(decx,head);
%        FF(i,head) = F(x(varF(1:nv(head),head))*b(end-nv(head)+1:end)+1,head);
%        disp(x*b(end-nv(head)+1:end)+1)
%        FF(i,head) = F(x*b(end-nv(head)+1:end)+1,head);
    end
end
% disp(FF(1:p^nv(head),head));
